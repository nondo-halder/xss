# core/scanner.py placeholder
# core/scanner.py

import requests
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from core import payloads
from utils import logger

def inject_payload_into_url(url, param, payload):
    """Inject payload into a specific GET parameter of the URL."""
    parsed = urlparse(url)
    qs = parse_qs(parsed.query)
    qs[param] = payload
    new_query = urlencode(qs, doseq=True)
    new_url = urlunparse(parsed._replace(query=new_query))
    return new_url

def is_reflected_xss(payload, response_text):
    return payload in response_text

def detect_get_params(url):
    """Extract all GET parameters from the URL."""
    return list(parse_qs(urlparse(url).query).keys())

def test_xss_in_url(url, settings):
    vulnerable = []
    params = detect_get_params(url)
    if not params:
        return vulnerable

    for payload in payloads.generate():
        for param in params:
            test_url = inject_payload_into_url(url, param, payload)
            try:
                headers = {}
                if 'cookie' in settings:
                    headers['Cookie'] = settings['cookie']

                resp = requests.get(test_url, headers=headers, timeout=5)
                if is_reflected_xss(payload, resp.text):
                    logger.vuln(param, payload, test_url)
                    vulnerable.append((param, payload, test_url))
                elif settings.get("webhook") and "xss" in payload:
                    # Trigger Blind XSS
                    requests.get(test_url, headers=headers)
            except requests.RequestException:
                continue
    return vulnerable

def start_scan(urls, settings):
    for url in urls:
        logger.section(url)
        vulns = test_xss_in_url(url, settings)
        if not vulns:
            logger.log("[-] No reflected XSS found.\n")
