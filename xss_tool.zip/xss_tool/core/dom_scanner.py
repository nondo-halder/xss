# core/dom_scanner.py placeholder

# core/dom_scanner.py

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from urllib.parse import urljoin
import time

def setup_browser():
    chrome_options = Options()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    driver = webdriver.Chrome(options=chrome_options)
    return driver

def test_dom_xss(url, param, payload):
    """
    Launch the URL with payload and detect DOM-based XSS using Selenium.
    """
    full_url = f"{url}?{param}={payload}"
    driver = setup_browser()
    try:
        driver.get(full_url)
        time.sleep(2)  # Wait for scripts to execute

        # Check if payload is executed
        if "alert" in driver.page_source or payload in driver.page_source:
            print(f"[DOM-XSS] Potential DOM-based XSS detected on: {full_url}")
            return True
        else:
            print(f"[DOM-XSS] No DOM-based XSS found on: {full_url}")
            return False
    except Exception as e:
        print(f"[!] Selenium error: {e}")
        return False
    finally:
        driver.quit()
