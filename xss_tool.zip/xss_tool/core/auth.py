# core/auth.py placeholder

# core/auth.py

import requests

def login_with_credentials(login_url, username, password, username_field="username", password_field="password"):
    """
    Login using username & password and return a requests.Session object.
    """
    session = requests.Session()
    payload = {
        username_field: username,
        password_field: password
    }
    try:
        response = session.post(login_url, data=payload, timeout=10)
        if response.ok and response.url != login_url:
            print("[+] Login successful.")
            return session
        else:
            print("[-] Login failed.")
            return None
    except requests.RequestException as e:
        print(f"[-] Login error: {e}")
        return None

def session_from_cookie(cookie_string):
    """
    Return a requests.Session object with cookie headers set.
    """
    session = requests.Session()
    cookie_dict = {}
    try:
        for part in cookie_string.split(";"):
            name, value = part.strip().split("=", 1)
            cookie_dict[name.strip()] = value.strip()
        session.cookies.update(cookie_dict)
        print("[+] Session created from cookie.")
        return session
    except Exception as e:
        print(f"[-] Cookie parsing error: {e}")
        return None
