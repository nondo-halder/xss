# core/crawler.py placeholder

# core/crawler.py

import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse

visited_links = set()

def is_valid(url):
    """Check if URL is valid and absolute."""
    parsed = urlparse(url)
    return bool(parsed.netloc) and bool(parsed.scheme)

def get_all_links(base_url):
    """Extract all anchor tag hrefs from a page."""
    try:
        response = requests.get(base_url, timeout=5)
        soup = BeautifulSoup(response.content, "html.parser")
        links = set()

        for a_tag in soup.find_all("a", href=True):
            href = a_tag.attrs.get("href")
            full_url = urljoin(base_url, href)
            if is_valid(full_url) and full_url not in visited_links:
                links.add(full_url)

        return links
    except requests.RequestException:
        return set()

def crawl(start_url, max_depth=2):
    """Recursively crawl pages starting from start_url."""
    to_visit = [(start_url, 0)]
    all_found_urls = []

    while to_visit:
        current_url, depth = to_visit.pop(0)
        if current_url in visited_links or depth > max_depth:
            continue

        visited_links.add(current_url)
        all_found_urls.append(current_url)

        new_links = get_all_links(current_url)
        for link in new_links:
            to_visit.append((link, depth + 1))

    return all_found_urls

