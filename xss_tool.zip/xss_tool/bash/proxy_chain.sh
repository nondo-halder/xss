# bash/proxy_chain.sh placeholder

#!/bin/bash

# ┌───────────────────────────────────────────────┐
# │ PROXY CHAINING SCRIPT (HTTP/SOCKS)           │
# └───────────────────────────────────────────────┘

PROXY_LIST="proxies.txt"

if [ ! -f "$PROXY_LIST" ]; then
    echo "[-] $PROXY_LIST not found! Please create it with list of proxies."
    echo "Example format (one per line):"
    echo "http://proxy1:port"
    echo "socks5://proxy2:port"
    exit 1
fi

URL=$1

if [ -z "$URL" ]; then
    echo "Usage: $0 <url>"
    exit 1
fi

echo "[*] Starting proxy chain test on $URL"
echo "---------------------------------------"

while IFS= read -r proxy; do
    echo "[*] Trying via: $proxy"
    curl -x "$proxy" -s -o /dev/null -w " -> Status: %{http_code}\n" "$URL"
    sleep 1
done < "$PROXY_LIST"
