# bash/rotate_ip.sh placeholder

#!/bin/bash

# ┌───────────────────────────────────────────────┐
# │ TOR IP ROTATOR SCRIPT                        │
# └───────────────────────────────────────────────┘

# Make sure TOR is running as a service
# You can start it using: sudo service tor start

function change_ip() {
    echo "[*] Rotating IP via TOR..."
    echo -e 'AUTHENTICATE ""\r\nsignal NEWNYM\r\nQUIT' | nc 127.0.0.1 9051 > /dev/null
    sleep 3
    echo "[+] New TOR identity requested!"
}

function current_ip() {
    echo -n "[*] Current IP: "
    curl --socks5 127.0.0.1:9050 -s https://api.ipify.org
    echo
}

# MAIN
change_ip
current_ip
