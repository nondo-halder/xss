# main.py placeholder

# main.py
import argparse
from core import crawler, scanner, auth
from utils import logger
import json
import os

def load_settings():
    settings_path = os.path.join("config", "settings.json")
    if os.path.exists(settings_path):
        with open(settings_path, "r") as f:
            return json.load(f)
    return {}

def main():
    parser = argparse.ArgumentParser(description="XSS Dominator - Advanced XSS Scanner")
    parser.add_argument("--url", help="Target URL to scan", required=True)
    parser.add_argument("--webhook", help="Webhook URL for Blind XSS", default=None)
    parser.add_argument("--cookie", help="Session cookie for authenticated scan", default=None)
    parser.add_argument("--login", help="Login mode: provide JSON like '{\"url\":\"...\", \"username\":\"...\", \"password\":\"...\"}'")
    args = parser.parse_args()

    logger.banner()
    logger.log(f"🎯 Target URL: {args.url}")
    logger.log("🚀 Starting scan...\n")

    settings = load_settings()
    if args.cookie:
        settings['cookie'] = args.cookie
    if args.webhook:
        settings['webhook'] = args.webhook

    # Optional login
    if args.login:
        logger.log("🔐 Attempting login...")
        login_info = json.loads(args.login)
        cookies = auth.login_and_get_cookies(login_info)
        settings['cookie'] = cookies

    # Start crawling
    urls = crawler.crawl(args.url)
    logger.log(f"🕷️ Crawled {len(urls)} URLs")

    # Start scanning
    scanner.start_scan(urls, settings)

if __name__ == "__main__":
    main()

