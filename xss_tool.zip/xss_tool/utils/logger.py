# utils/logger.py placeholder

# utils/logger.py

from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()

def banner():
    banner_text = """
██╗  ██╗███████╗███████╗    ██████╗  ██████╗ ███╗   ███╗██╗███╗   ██╗ ██████╗ ███████╗██████╗ 
██║ ██╔╝██╔════╝██╔════╝    ██╔══██╗██╔═══██╗████╗ ████║██║████╗  ██║██╔════╝ ██╔════╝██╔══██╗
█████╔╝ █████╗  ███████╗    ██████╔╝██║   ██║██╔████╔██║██║██╔██╗ ██║██║  ███╗█████╗  ██████╔╝
██╔═██╗ ██╔══╝  ╚════██║    ██╔═══╝ ██║   ██║██║╚██╔╝██║██║██║╚██╗██║██║   ██║██╔══╝  ██╔═══╝ 
██║  ██╗███████╗███████║    ██║     ╚██████╔╝██║ ╚═╝ ██║██║██║ ╚████║╚██████╔╝███████╗██║     
╚═╝  ╚═╝╚══════╝╚══════╝    ╚═╝      ╚═════╝ ╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚══════╝╚═╝     
"""
    console.print(Panel.fit(banner_text, title="[bold green]XSS Dominator", subtitle="By Offensive AI", style="bold cyan"))

def log(message):
    console.print(message)

def section(url):
    console.rule(f"[bold yellow]🔍 Scanning: {url}", style="bright_blue")

def vuln(param, payload, url):
    console.print(f"[bold green]✔ VULNERABLE! Reflected XSS Detected[/bold green]")
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Parameter", style="cyan")
    table.add_column("Payload", style="red")
    table.add_column("URL", style="green")

    table.add_row(param, payload, url)
    console.print(table)
