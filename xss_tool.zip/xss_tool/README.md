# README.md placeholder

# 🛡️ XSS Dominator

**XSS Dominator** হল একটি হাইব্রিড (Python + Bash) এক্সট্রিমলি অ্যাডভান্সড XSS ভলনারেবিলিটি স্ক্যানার, যা সাপোর্ট করে:

- Reflected XSS 🔁
- Stored XSS 🗃️
- DOM-based XSS 🧠
- Blind XSS 🎯 (via Webhook)
- WAF Bypass 🔓
- TOR/Proxy IP Rotation 🌐
- Full-site Crawling 🕷️
- Auto Login & Session Scanning 🔐

---

## 📁 Folder Structure

