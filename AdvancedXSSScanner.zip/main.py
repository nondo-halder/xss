from modules.crawler import crawl_site
from modules.scanner import scan_inputs
from modules.auth import login_and_get_session
from modules.payloads import generate_payloads
from modules.tor_proxy import start_tor_session
from modules.utils import log, banner

def main():
    banner()
    url = input("Target URL: ").strip()
    auth_option = input("Login required? (y/n): ").strip().lower()

    session = None
    if auth_option == 'y':
        session = login_and_get_session()

    proxies = start_tor_session()
    payloads = generate_payloads()
    inputs = crawl_site(url, session=session)

    for input_point in inputs:
        scan_inputs(url, input_point, payloads, session=session, proxies=proxies)

if __name__ == "__main__":
    main()
