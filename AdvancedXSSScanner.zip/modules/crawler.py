import requests
from bs4 import BeautifulSoup

def crawl_site(url, session=None):
    print(f"[+] Crawling site: {url}")
    req = session.get(url) if session else requests.get(url)
    soup = BeautifulSoup(req.text, 'html.parser')
    forms = soup.find_all('form')
    inputs = []
    for form in forms:
        action = form.get('action')
        method = form.get('method', 'get').lower()
        input_tags = form.find_all('input')
        input_names = [i.get('name') for i in input_tags if i.get('name')]
        inputs.append({
            'action': action,
            'method': method,
            'inputs': input_names
        })
    return inputs
