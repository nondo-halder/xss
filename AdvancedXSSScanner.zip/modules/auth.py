import requests

def login_and_get_session():
    session = requests.Session()
    login_url = input("Login URL: ").strip()
    user_field = input("Username field name: ")
    pass_field = input("Password field name: ")
    username = input("Username: ")
    password = input("Password: ")

    data = {user_field: username, pass_field: password}
    session.post(login_url, data=data)
    return session
