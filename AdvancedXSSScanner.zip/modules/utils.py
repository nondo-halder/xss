from colorama import Fore, Style

def log(message, level="info"):
    color = {"info": Fore.CYAN, "green": Fore.GREEN, "red": Fore.RED}.get(level, Fore.WHITE)
    print(color + message + Style.RESET_ALL)

def banner():
    print(Fore.YELLOW + "[=] Advanced XSS Scanner by ChatGPT
" + Style.RESET_ALL)
