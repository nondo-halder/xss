import requests
from modules.utils import log

def scan_inputs(base_url, input_point, payloads, session=None, proxies=None):
    print(f"[+] Scanning: {input_point['action']}")
    for payload in payloads:
        data = {name: payload for name in input_point['inputs']}
        target_url = base_url + input_point['action']
        if input_point['method'] == 'post':
            r = session.post(target_url, data=data, proxies=proxies) if session else requests.post(target_url, data=data, proxies=proxies)
        else:
            r = session.get(target_url, params=data, proxies=proxies) if session else requests.get(target_url, params=data, proxies=proxies)

        if payload in r.text:
            log(f"[VULNERABLE] {target_url} with payload: {payload}", "green")
