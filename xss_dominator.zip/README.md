# XSS Dominator

Hybrid Python + Bash XSS Scanner
