📦 Ultimate XSS Scanner (Docker Edition)

🧪 How to use:
----------------------------
1. Build Docker image:
   docker build -t xss-scanner .

2. Run the scanner:
   docker run --rm -v "$PWD:/app" xss-scanner http://example.com

3. Output:
   xss_scan_report.json will be saved in your local folder.

Note:
- Replace "http://example.com" with your target.
- You can add optional flags like --threads, --no-evasion, etc.
