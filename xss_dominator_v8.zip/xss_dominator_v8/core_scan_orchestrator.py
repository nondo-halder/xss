import os
import sys
print("[*] Orchestrating full scan...")
os.system("python3 payload_bank_updater.py")
os.system("python3 payload_generator_ai.py")
os.system("python3 auth_handler.py")
os.system("python3 stored_xss_scan.py")
os.system("python3 login_bypass_tester.py")
os.system("node dom_scanner.js " + sys.argv[1])
os.system("python3 report_generator.py")
print("[+] XSS Dominator v8 scan complete!")
