const puppeteer = require('puppeteer');
console.log("[DOM] Launching Puppeteer...");
(async () => {
    const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.goto(process.argv[2]);
    console.log("[DOM] Scan complete.");
    await browser.close();
})();