#!/bin/bash
set -e
echo "[*] Starting XSS Dominator v8..."
python3 core_scan_orchestrator.py "$@"
