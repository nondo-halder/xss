const puppeteer = require('puppeteer');
const fs = require('fs');

(async () => {
    console.log("[DOM] Launching headless browser...");
    const browser = await puppeteer.launch({ headless: true });
    const page = await browser.newPage();
    const url = process.argv[2];
    await page.goto(url, { waitUntil: 'domcontentloaded' });

    let payloads = JSON.parse(fs.readFileSync('xssdominator_results/payloads.json', 'utf8'));
    let found = [];

    for (let p of payloads) {
        try {
            await page.evaluate((pl) => {
                let d = document.createElement('div');
                d.innerHTML = pl;
                document.body.appendChild(d);
            }, p);
            found.push({url: url, payload: p, type: "dom"});
        } catch {}
    }

    await browser.close();
    let report = found.length ? found : [];
    let file = 'xssdominator_results/dom_vulnerabilities.json';
    fs.writeFileSync(file, JSON.stringify(report));
})();
