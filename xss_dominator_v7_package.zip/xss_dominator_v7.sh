#!/bin/bash
set -e
[ "$DEBUG" = true ] && set -x

TARGET_URL="$1"
if [ -z "$TARGET_URL" ]; then
    echo "[!] Usage: $0 <target_url>"
    exit 1
fi

echo "[*] Initializing XSS Dominator v7..."
mkdir -p xssdominator_results

echo "[*] Step 1: Running AI-based payload generator..."
python3 payload_gen.py "$TARGET_URL"

echo "[*] Step 2: Crawling and scanning target..."
python3 scanner.py "$TARGET_URL"

echo "[*] Step 3: Performing DOM-based analysis with headless browser..."
node puppeteer_dom_scan.js "$TARGET_URL"

echo "[*] Step 4: Generating final report..."
python3 report_builder.py

echo "[+] Scan completed! Results saved in 'xssdominator_results/'"
