import json, os
print("[REPORT] Generating final report...")
result_dir = "xssdominator_results"
html_report = os.path.join(result_dir, "final_report.html")
vulns = []

for file in ["vulnerabilities.json", "dom_vulnerabilities.json"]:
    path = os.path.join(result_dir, file)
    if os.path.exists(path):
        with open(path) as f:
            vulns.extend(json.load(f))

with open(html_report, "w") as f:
    f.write("<html><body><h1>XSS Scan Report</h1><ul>")
    for v in vulns:
        f.write(f"<li><b>Type:</b> {v.get('type')} | <b>Payload:</b> {v.get('payload')} | <b>URL:</b> {v.get('url')}</li>")
    f.write("</ul></body></html>")
print("[REPORT] Report saved to", html_report)
