import sys, json, requests, urllib.parse, os
print("[SCAN] Scanning for reflected XSS...")
target = sys.argv[1]
with open("xssdominator_results/payloads.json") as f:
    payloads = json.load(f)

vulns = []
for p in payloads:
    test_url = f"{target}?xss={urllib.parse.quote(p)}"
    try:
        r = requests.get(test_url, timeout=5)
        if p in r.text:
            print(f"[!] Reflected XSS detected with payload: {p}")
            vulns.append({"url": test_url, "payload": p, "type": "reflected"})
    except:
        pass

with open("xssdominator_results/vulnerabilities.json", "w") as f:
    json.dump(vulns, f)
